//
//  AsientosView.swift
//  Cinevol2
//
//  Created by Facultad de Contaduría y Administración on 25/05/23.
//

import Foundation
import UIKit

class AsientosView: UIViewController{
    
    
    @IBOutlet var asiento1: UIButton!
    @IBOutlet var asiento2: UIButton!
    @IBOutlet var asiento3: UIButton!
    @IBOutlet var asiento4: UIButton!
    @IBOutlet var asiento5: UIButton!
    @IBOutlet var asiento6: UIButton!
    @IBOutlet var asiento7: UIButton!
    @IBOutlet var asiento8: UIButton!
    @IBOutlet var asiento9: UIButton!
    @IBOutlet var asiento10: UIButton!
    @IBOutlet var asiento11: UIButton!
    @IBOutlet var asiento12: UIButton!
    @IBOutlet var asiento13: UIButton!
    @IBOutlet var asiento14: UIButton!
    @IBOutlet var asiento15: UIButton!
    @IBOutlet var asiento16: UIButton!
    @IBOutlet var asiento17: UIButton!
    @IBOutlet var asiento18: UIButton!
    @IBOutlet var asiento19: UIButton!
    @IBOutlet var asiento20: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func accionA1(_ sender: UIButton) {
        asiento1.tintColor = .yellow
    }
    
    @IBAction func accionA2(_ sender: UIButton){
        asiento2.tintColor = .yellow
    }
    
    @IBAction func accionA3(_ sender: UIButton){
        asiento3.tintColor = .yellow
    }
    
    @IBAction func accionA4(_ sender: UIButton){
        asiento4.tintColor = .yellow
    }
    
    @IBAction func accionA5(_ sender: UIButton){
        asiento5.tintColor = .yellow
    }
    
    @IBAction func accionA6(_ sender: UIButton){
        asiento6.tintColor = .yellow
    }
    
    @IBAction func accionA7(_ sender: UIButton){
        asiento7.tintColor = .yellow
    }
    
    @IBAction func accionA8(_ sender: UIButton){
        asiento8.tintColor = .yellow
    }
    
    @IBAction func accionA9(_ sender: UIButton){
        asiento9.tintColor = .yellow
    }
    
    @IBAction func accionA10(_ sender: UIButton){
        asiento10.tintColor = .yellow
    }
    
    @IBAction func accionA11(_ sender: UIButton){
        asiento11.tintColor = .yellow
    }
    
    @IBAction func accionA12(_ sender: UIButton){
        asiento12.tintColor = .yellow
    }
    
    @IBAction func accionA13(_ sender: UIButton){
        asiento13.tintColor = .yellow
    }
    
    @IBAction func accionA14(_ sender: UIButton){
        asiento14.tintColor = .yellow
    }
    
    @IBAction func accionA15(_ sender: UIButton){
        asiento15.tintColor = .yellow
    }
    
    @IBAction func accionA16(_ sender: UIButton){
        asiento16.tintColor = .yellow
    }
    
    @IBAction func accionA17(_ sender: UIButton){
        asiento17.tintColor = .yellow
    }
    
    @IBAction func accionA18(_ sender: UIButton){
        asiento18.tintColor = .yellow
    }
    
    @IBAction func accionA19(_ sender: UIButton){
        asiento19.tintColor = .yellow
    }
    
    @IBAction func accionA20(_ sender: UIButton){
        asiento20.tintColor = .yellow
    }
    
}
